#!/usr/bin/env bash
set -euo pipefail

REPO_DIR="$(cd "$(dirname "$0")" && pwd)"
CRAN="https://packagemanager.posit.co/cran/__linux__/noble/latest"
R_LIBS_USER="/builds/ausplotsR/rlib"
CONTAINER_NAME="ausplotsR-ci-local"

cleanup() {
  echo '==> Cleaning up container and rlib/'
  docker rm -f "$CONTAINER_NAME" 2>/dev/null || true
  docker run --rm -v "${REPO_DIR}:/builds/ausplotsR" rocker/r-ver:4.4.3 rm -rf /builds/ausplotsR/rlib
}
trap cleanup EXIT

docker run --name "$CONTAINER_NAME" \
  -v "${REPO_DIR}:/builds/ausplotsR" \
  -w /builds/ausplotsR \
  -e CI_PROJECT_DIR=/builds/ausplotsR \
  -e RGL_USE_NULL=TRUE \
  rocker/r-ver:4.4.3 \
  bash -c "
    set -e
    CRAN=\"${CRAN}\"
    R_LIBS_USER=\"${R_LIBS_USER}\"

    echo '==> Installing system dependencies'
    apt-get update -qq && apt-get install -y --no-install-recommends libglu1-mesa-dev libgl1-mesa-dev libglpk-dev

    echo '==> Creating R library directory'
    mkdir -p \"\$R_LIBS_USER\"

    echo '==> Installing R tooling (remotes, pkgload, testthat, mockery, BiocManager)'
    Rscript -e \".libPaths('\$R_LIBS_USER'); install.packages(c('remotes','pkgload','testthat','mockery','BiocManager'), lib='\$R_LIBS_USER', repos='\$CRAN', quiet=TRUE)\"

    echo '==> Installing package dependencies'
    Rscript -e \".libPaths('\$R_LIBS_USER'); remotes::install_deps('.', dependencies=c('Depends','Imports','LinkingTo'), lib='\$R_LIBS_USER', repos='\$CRAN')\"

    echo '==> Installing adiv (Bioconductor)'
    Rscript -e \".libPaths('\$R_LIBS_USER'); options(repos=c(CRAN='\$CRAN')); BiocManager::install('adiv', lib='\$R_LIBS_USER', ask=FALSE, update=FALSE, quiet=TRUE)\"

    echo '==> Running tests'
    Rscript -e \".libPaths('\$R_LIBS_USER'); testthat::test_local('.', stop_on_failure=TRUE)\"
  "